% go back to launcher and launch it

if ~exist('launcher.m','file')

    cd ..

end

launcher
